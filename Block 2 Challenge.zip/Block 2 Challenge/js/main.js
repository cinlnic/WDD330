import Books from './Books.js';

const books = new Books('bookList');

books.showBooks();


